#ifndef WILDFILE_H
#define WILDFILE_H

void MyGlob(int *argc, char **argv[], int attrib);

#endif
