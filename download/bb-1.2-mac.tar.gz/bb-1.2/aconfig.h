/* aconfig.h.  Generated automatically by configure.  */
#ifndef ACONFIG_H
#define ACONFIG_H
/* #undef C_ALLOCA */
/* #undef const */
#define HAVE_ALLOCA 1
#define HAVE_ALLOCA_H 1
#define HAVE_FTIME 1
#define HAVE_SELECT 1
/* #undef HAVE_LONG_DOUBLE */
/* #undef inline */
/* #undef _POSIX_SOURCE */
#define STDC_HEADERS 1
/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1
#define HAVE_GETTIMEOFDAY 1
/* #undef HAVE_USLEEP */
/* #undef HAVE_TERMATTRS */
/* #undef HAVE_MOUSEMASK */
/* #undef HAVE_SETITIMER */
/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1
/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1
/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1
/* #undef SIZEOF_SHORT */
/* #undef SIZEOF_INT */
/* #undef SIZEOF_LONG */
#endif
